'use client'
// DESTINAZIONE: src/app/for-you/page.tsx
// V5: Serendipity badge + Award badge + Seasonal badge + Social boost display +
//     lowConfidence banner + Feedback granulare micro-menu + Anti-ripetizione (recommendations_shown)

import { useState, useEffect, useCallback, memo, useRef } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  Sparkles, RefreshCw, SlidersHorizontal, Gamepad2, Tv, Film,
  Zap, Plus, Bookmark, X, Check, ChevronDown, ChevronUp, Users,
  ThumbsDown, Eye, Flame, Brain, Star, ArrowRight, Clapperboard, Swords,
  TrendingUp, Search, BookmarkCheck, Trophy, Calendar,
  MessageCircleQuestion, Tag, MonitorPlay, AlertCircle, Layers,
  Dices,
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { Avatar } from '@/components/ui/Avatar'
import { useLocale } from '@/lib/locale'
import { SkeletonForYouRow } from '@/components/ui/SkeletonCard'
import { MediaDetailsDrawer } from '@/components/media/MediaDetailsDrawer'
import type { MediaDetails } from '@/components/media/MediaDetailsDrawer'
import { usePullToRefresh } from '@/hooks/usePullToRefresh'
import { PullToRefreshIndicator } from '@/components/ui/ErrorState'
import { PreferencesModal } from '@/components/for-you/PreferencesModal'
import { androidBack } from '@/hooks/androidBack'
import { DNAWidget } from '@/components/for-you/DNAWidget'
import type { TasteProfile } from '@/components/for-you/DNAWidget'
import { EmptyState } from '@/components/ui/EmptyState'
import { profileInvalidateBridge } from '@/hooks/profileInvalidateBridge'

// V5: Tipi per feedback granulare
type FeedbackAction = 'not_interested' | 'already_seen' | 'added' | 'wishlist_add';
type FeedbackReason = 'too_similar' | 'not_my_genre' | 'already_know' | 'bad_rec' | undefined;

type MediaType = 'anime' | 'manga' | 'movie' | 'tv' | 'game' | 'boardgame'

interface FriendActivity {
  userId: string; username: string; displayName?: string; avatarUrl?: string
  mediaId: string; mediaTitle: string; mediaCover?: string; mediaType: string; updatedAt: string
  isHighSim?: boolean; simScore?: number
}

const TYPE_ICONS: Record<MediaType, React.ElementType> = {
  anime: Swords, manga: Layers, movie: Film, tv: Tv, game: Gamepad2,
  boardgame: Dices, }

const TYPE_LABEL: Record<string, string> = {
  anime: 'Anime', manga: 'Manga', movie: 'Film', tv: 'Serie TV', game: 'Videogioco',
  boardgame: 'Gioco da Tavolo', }

const TYPE_COLORS: Record<string, string> = {
  anime: 'from-sky-500 to-blue-600',
  manga: 'from-orange-500 to-red-500',
  movie: 'from-red-500 to-rose-600',
  tv: 'from-purple-500 to-violet-600',
  game: 'from-emerald-500 to-green-600',
  boardgame: 'from-amber-500 to-yellow-600',
  }

function triggerTasteDelta(options: {
  action: 'rating' | 'status_change' | 'wishlist_add' | 'rewatch' | 'progress'
  mediaId: string; mediaType: string; genres: string[]
  rating?: number; prevRating?: number; status?: string; prevStatus?: string
}) {
  fetch('/api/taste/update', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(options) }).catch(() => {})
}

function MatchBadge({ score }: { score: number }) {
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-violet-300 bg-violet-500/10 border border-violet-500/20 px-1.5 py-0.5 rounded-full">
      <Star size={8} fill="currentColor" />{score}%
    </span>
  )
}


interface Recommendation {
  id: string; title: string; type: MediaType; coverImage?: string; year?: number
  genres: string[]; score?: number; description?: string; why: string
  matchScore: number; isDiscovery?: boolean
  episodes?: number
  tags?: string[]
  keywords?: string[]
  isContinuity?: boolean
  continuityFrom?: string
  creatorBoost?: string
  isSerendipity?: boolean
  isAwardWinner?: boolean
  isSeasonal?: boolean
  socialBoost?: string
  friendWatching?: string
  // Extra metadata per il drawer
  authors?: string[]
  developers?: string[]
  platforms?: string[]
  min_players?: number
  max_players?: number
  playing_time?: number
  complexity?: number
}

// V3: Continuity Section
const ContinuitySection = memo(function ContinuitySection({ items, onFeedback, onDetail, dismissedIds }: {
  items: Recommendation[]
  onFeedback: (i: Recommendation, a: FeedbackAction, reason?: FeedbackReason) => void
  onDetail?: (i: Recommendation) => void
  dismissedIds: Set<string>
}) {
  const visible = items.filter(i => i.isContinuity && !dismissedIds.has(i.id))
  if (!visible.length) return null

  return (
    <div className="mb-12">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-8 h-8 bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
          <ArrowRight size={16} className="text-white" />
        </div>
        <div>
          <h2 className="text-base font-bold text-white">Continua a guardare</h2>
          <p className="text-[10px] text-amber-400">Sequel e capitoli successivi dei tuoi titoli completati</p>
        </div>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-3 scrollbar-hide">
        {visible.map(item => {
          const Icon = TYPE_ICONS[item.type]
          return (
            <div key={item.id} className="flex-shrink-0 w-44 group relative cursor-pointer" onClick={() => onDetail?.(item)}>
              <div className="relative h-64 rounded-2xl overflow-hidden bg-zinc-900 mb-2">
                {item.coverImage
                  ? <img src={item.coverImage} alt={item.title} className="w-full h-full object-cover transition-transform group-hover:scale-105" loading="lazy" />
                  : <div className="w-full h-full flex items-center justify-center"><Icon size={36} className="text-zinc-700" /></div>
                }
                <div className="absolute inset-0 ring-2 ring-amber-500/40 rounded-2xl pointer-events-none" />
                <div className="absolute top-2 left-2 bg-amber-500/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-1">
                  <ArrowRight size={8} />Sequel
                </div>
                <div className="absolute top-2 right-2 bg-black/70 text-[9px] text-zinc-300 px-1.5 py-0.5 rounded-full">
                  {TYPE_LABEL[item.type]}
                </div>
                <div className="absolute bottom-0 inset-x-0 h-20 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2">
                  <button onClick={(e) => { e.stopPropagation(); onFeedback(item, 'already_seen') }}
                    className="w-7 h-7 flex items-center justify-center rounded-full bg-black/60 backdrop-blur-sm text-zinc-300 hover:text-white hover:bg-zinc-600/60 transition-colors">
                    <Eye size={11} />
                  </button>
                </div>
              </div>
              <p className="text-xs font-bold text-white leading-tight line-clamp-2 mb-0.5">{item.title}</p>
            </div>
          )
        })}
      </div>
    </div>
  )
})

const RecommendationCard = memo(function RecommendationCard({ item, onFeedback, onSimilar, onDetail, isSimilarLoading, dismissed, showDetails }: {
  item: Recommendation
  onFeedback: (i: Recommendation, a: FeedbackAction, reason?: FeedbackReason) => void
  onSimilar?: (i: Recommendation) => void
  onDetail?: (i: Recommendation) => void
  isSimilarLoading: boolean; dismissed: boolean
  showDetails?: boolean
}) {
  const Icon = TYPE_ICONS[item.type]; const colorClass = TYPE_COLORS[item.type]
  if (dismissed) return null

  const episodeLabel = item.type === 'manga'
    ? (item.episodes ? `${item.episodes} cap.` : null)
    : (item.episodes && item.type !== 'movie' ? `${item.episodes} ep.` : null)

  return (
    <div className={`flex-shrink-0 group ${showDetails ? 'w-52' : 'w-40'}`}>
      <div
        className={`relative ${showDetails ? 'h-72' : 'h-60'} rounded-2xl overflow-hidden bg-zinc-900 mb-2 cursor-pointer`}
        onClick={() => onDetail?.(item)}
      >
        {item.coverImage
          ? <img src={item.coverImage} alt={item.title} className="w-full h-full object-cover transition-transform group-hover:scale-105" loading="lazy" onError={e => { (e.target as HTMLImageElement).style.display = 'none' }} />
          : <div className="w-full h-full flex items-center justify-center"><Icon size={32} className="text-zinc-700" /></div>
        }
        {/* Bordo inset sottile — invisibile su cover colorate, separa quelle nere dallo sfondo */}
        <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/10 pointer-events-none" />
        {/* Solo badge tipo media in alto a sinistra */}
        <div className={`absolute top-2 left-2 bg-gradient-to-r ${colorClass} text-white text-[10px] font-bold px-2 py-0.5 rounded-full`}>
          {TYPE_LABEL[item.type] || item.type.toUpperCase()}
        </div>
        {/* Pulsanti azione in basso */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
          <button onClick={(e) => { e.stopPropagation(); onFeedback(item, 'not_interested') }} title="Non mi interessa"
            className="w-7 h-7 flex items-center justify-center rounded-full bg-black/60 backdrop-blur-sm text-zinc-300 hover:text-red-300 hover:bg-red-900/60 transition-colors">
            <ThumbsDown size={11} />
          </button>
          <button onClick={(e) => { e.stopPropagation(); onFeedback(item, 'already_seen') }} title="L'ho già visto"
            className="w-7 h-7 flex items-center justify-center rounded-full bg-black/60 backdrop-blur-sm text-zinc-300 hover:text-white hover:bg-zinc-600/60 transition-colors">
            <Eye size={11} />
          </button>
          {onSimilar && (
            <button onClick={(e) => { e.stopPropagation(); onSimilar(item) }} disabled={isSimilarLoading} title="Simili"
              className={`w-7 h-7 flex items-center justify-center rounded-full backdrop-blur-sm transition-colors ${isSimilarLoading ? 'bg-violet-900/60 text-violet-300' : 'bg-black/60 text-zinc-300 hover:text-violet-200 hover:bg-violet-900/60'}`}>
              {isSimilarLoading ? <RefreshCw size={11} className="animate-spin" /> : <Search size={11} />}
            </button>
          )}
        </div>
      </div>
      <p className="text-xs font-semibold text-white leading-tight line-clamp-2 mb-1">{item.title}</p>
      {/* Metadati: anno · episodi · voto (sempre visibile, voto a destra dell'anno) */}
      <div className="flex items-center gap-1.5 flex-wrap mb-1">
        {item.year && <p className="text-[10px] text-zinc-500">{item.year}</p>}
        {item.score && (
          <span className="flex items-center gap-0.5 text-[10px] text-yellow-400 font-semibold">
            <Star size={8} fill="currentColor" />{Math.min(item.score, 5).toFixed(1)}
          </span>
        )}
        {episodeLabel && (
          <span className="text-[10px] text-zinc-500">{episodeLabel}</span>
        )}
      </div>
      <MatchBadge score={item.isContinuity ? 100 : item.matchScore} />
    </div>
  )
})


// Sezione "Simili a X" — persiste finché l'utente non la chiude o cerca un altro simile
// Barra di ricerca "Trova titoli simili a..." — stile identico alla navbar
// Cerca in tutte le API (AniList, TMDb, IGDB) in parallelo — stesso pattern della discover
const TYPE_LABEL_SEARCH: Record<string, string> = {
  anime: 'Anime', manga: 'Manga', movie: 'Film', tv: 'Serie TV',
  game: 'Videogioco', }

interface SearchSuggestion {
  id: string; title: string; type: string
  genres?: string[]; year?: number; coverImage?: string
  description?: string; keywords?: string[]
}

function SimilarSearchBar({ onSearch, loading }: {
  onSearch: (title: string, genres: string[], keywords?: string[], type?: string) => void
  loading: boolean
}) {
  const [query, setQuery] = useState('')
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([])
  const [searching, setSearching] = useState(false)
  const [open, setOpen] = useState(false)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  // Chiudi dropdown se si clicca fuori
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const fetchSuggestions = async (q: string) => {
    if (q.trim().length < 2) { setSuggestions([]); setOpen(false); return }
    setSearching(true)
    try {
      // Chiama tutte le API in parallelo — stesse della discover
      const [anilistRes, tmdbRes, igdbRes] = await Promise.allSettled([
        fetch(`/api/anilist?q=${encodeURIComponent(q)}`),
        fetch(`/api/tmdb?q=${encodeURIComponent(q)}&type=all&lang=it-IT`),
        fetch(`/api/igdb?q=${encodeURIComponent(q)}`),
      ])

      const all: SearchSuggestion[] = []
      const parse = (j: any) => Array.isArray(j) ? j : (j.results || j.data || [])

      if (anilistRes.status === 'fulfilled' && anilistRes.value.ok) {
        const j = await anilistRes.value.json()
        for (const r of parse(j).slice(0, 1)) {
          all.push({ id: r.id || r.external_id, title: r.title, type: r.type || 'anime', genres: r.genres, year: r.year, coverImage: r.coverImage || r.cover_image, keywords: r.tags })
        }
      }
      if (tmdbRes.status === 'fulfilled' && tmdbRes.value.ok) {
        const j = await tmdbRes.value.json()
        for (const r of parse(j).slice(0, 1)) {
          all.push({ id: r.id || r.external_id, title: r.title, type: r.type || 'movie', genres: r.genres, year: r.year, coverImage: r.coverImage || r.cover_image, description: r.description, keywords: r.keywords })
        }
      }
      if (igdbRes.status === 'fulfilled' && igdbRes.value.ok) {
        const j = await igdbRes.value.json()
        for (const r of parse(j).slice(0, 1)) {
          all.push({ id: r.id || r.external_id, title: r.title, type: 'game', genres: r.genres, year: r.year, coverImage: r.coverImage || r.cover_image, keywords: r.keywords })
        }
      }

      setSuggestions(all.slice(0, 4))
      setOpen(all.length > 0)
    } catch {}
    setSearching(false)
  }

  const handleChange = (v: string) => {
    setQuery(v)
    setOpen(false)
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => fetchSuggestions(v), 320)
  }

  const handleSelect = (s: SearchSuggestion) => {
    setQuery(s.title)
    setOpen(false)
    setSuggestions([])
    const genres = s.genres?.filter(Boolean) || []
    onSearch(s.title, genres, (s as any).keywords, s.type)
  }

  const handleClear = () => {
    setQuery('')
    setSuggestions([])
    setOpen(false)
  }

  return (
    <div ref={containerRef} className="relative mb-6">
      {/* Input — stile identico alla navbar */}
      <div className="relative">
        <Search
          size={14}
          className={`absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none transition-colors ${searching || loading ? 'text-violet-400 animate-pulse' : 'text-zinc-500'}`}
        />
        <input
          value={query}
          onChange={e => handleChange(e.target.value)}
          onFocus={() => suggestions.length > 0 && setOpen(true)}
          onKeyDown={e => {
            if (e.key === 'Escape') { setOpen(false); return }
            if (e.key === 'Enter' && query.trim().length >= 2) {
              setOpen(false)
              if (suggestions.length > 0) handleSelect(suggestions[0])
              else onSearch(query.trim(), [])
            }
          }}
          placeholder="Cerca un titolo per trovare contenuti simili…"
          className="w-full bg-zinc-900 border border-zinc-800 focus:border-violet-500 rounded-2xl pl-9 pr-8 py-2 text-sm text-white placeholder-zinc-600 focus:outline-none transition-colors"
        />
        {query && (
          <button onClick={handleClear} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 transition-colors">
            <X size={13} />
          </button>
        )}
      </div>

      {/* Dropdown suggerimenti — stile identico alla navbar */}
      {open && suggestions.length > 0 && (
        <div className="absolute top-full left-0 w-full mt-2 bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl shadow-black/50 z-[110]">
          {suggestions.map((s, i) => (
            <button key={`${s.id}-${i}`} onClick={() => handleSelect(s)}
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-zinc-800 transition-colors border-b border-zinc-800/50 last:border-0 text-left">
              {/* Copertina */}
              <div className="w-8 h-11 rounded-xl overflow-hidden bg-zinc-800 flex-shrink-0">
                {s.coverImage
                  ? <img src={s.coverImage} alt="" className="w-full h-full object-cover" />
                  : <div className="w-full h-full" />
                }
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white leading-tight truncate">{s.title}</p>
                <p className="text-xs text-violet-400">
                  {TYPE_LABEL_SEARCH[s.type] || s.type}{s.year ? ` · ${s.year}` : ''}
                </p>
              </div>
            </button>
          ))}
        </div>
      )}

      {open && query.length >= 2 && suggestions.length === 0 && !searching && (
        <div className="absolute top-full left-0 w-full mt-2 bg-zinc-900 border border-zinc-800 rounded-2xl px-4 py-3 text-sm text-zinc-500 shadow-2xl z-[110]">
          Nessun risultato trovato
        </div>
      )}
    </div>
  )
}

const SIMILAR_TYPE_FILTERS: Array<{ key: MediaType | 'all'; label: string }> = [
  { key: 'all',       label: 'Tutti' },
  { key: 'anime',     label: 'Anime' },
  { key: 'movie',     label: 'Film' },
  { key: 'tv',        label: 'Serie TV' },
  { key: 'game',      label: 'Videogiochi' },
  { key: 'manga',     label: 'Manga' },
]

const SimilarSection = memo(function SimilarSection({ sourceTitle, sourceType, items, onFeedback, onSimilar, onDetail, onClose, dismissedIds, similarLoadingId }: {
  sourceTitle: string
  sourceType: MediaType
  items: Recommendation[]
  onFeedback: (i: Recommendation, a: FeedbackAction, reason?: FeedbackReason) => void
  onSimilar?: (i: Recommendation) => void
  onDetail?: (i: Recommendation) => void
  onClose: () => void
  dismissedIds: Set<string>
  similarLoadingId?: string | null
}) {
  const [visibleCount, setVisibleCount] = useState(20)
  const [typeFilter, setTypeFilter] = useState<MediaType | 'all'>('all')

  // Tipi effettivamente presenti nei risultati
  const presentTypes = new Set(items.map(i => i.type))
  const activeFilters = SIMILAR_TYPE_FILTERS.filter(f => f.key === 'all' || presentTypes.has(f.key as MediaType))

  const filtered = typeFilter === 'all'
    ? items.filter(i => !dismissedIds.has(i.id))
    : items.filter(i => i.type === typeFilter && !dismissedIds.has(i.id))

  const shown = filtered.slice(0, visibleCount)
  const hasMore = filtered.length > visibleCount

  // Reset visibleCount quando cambia il filtro
  const handleFilterChange = (key: MediaType | 'all') => {
    setTypeFilter(key)
    setVisibleCount(20)
  }

  return (
    <div className="mb-10 rounded-3xl border border-violet-500/30 bg-violet-500/5 p-5">

      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-xl flex items-center justify-center shadow-lg flex-shrink-0">
          <Search size={15} className="text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="text-sm font-bold text-white">
            Titoli simili a <span className="text-violet-300">"{sourceTitle}"</span>
          </h2>
          <p className="text-[10px] text-zinc-500">
            {filtered.length} {filtered.length === items.filter(i => !dismissedIds.has(i.id)).length ? 'titoli trovati' : `di ${items.filter(i => !dismissedIds.has(i.id)).length} totali`}
          </p>
        </div>
        <button onClick={onClose}
          className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-all"
          title="Chiudi">
          <X size={15} />
        </button>
      </div>

      {/* Filtri per tipo — pill scrollabili */}
      {activeFilters.length > 2 && (
        <div className="flex gap-2 overflow-x-auto pb-3 scrollbar-hide mb-4">
          {activeFilters.map(({ key, label }) => {
            const count = key === 'all'
              ? items.filter(i => !dismissedIds.has(i.id)).length
              : items.filter(i => i.type === key && !dismissedIds.has(i.id)).length
            const isActive = typeFilter === key
            return (
              <button key={key} onClick={() => handleFilterChange(key)}
                className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                  isActive
                    ? 'bg-violet-600 border-violet-500 text-white'
                    : 'bg-zinc-800/60 border-zinc-700 text-zinc-400 hover:border-zinc-500 hover:text-zinc-300'
                }`}>
                {key !== 'all' && <span className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${TYPE_COLORS[key as MediaType]}`} />}
                {label}
                <span className={`text-[10px] ${isActive ? 'text-violet-200' : 'text-zinc-600'}`}>{count}</span>
              </button>
            )
          })}
        </div>
      )}

      {filtered.length === 0 ? (
        <p className="text-sm text-zinc-500 text-center py-6">Nessun titolo trovato per questo filtro.</p>
      ) : (
        <div className="flex gap-4 overflow-x-auto pb-3 scrollbar-hide">
          {shown.map(item => (
            <RecommendationCard
              key={item.id}
              item={item}
              onFeedback={onFeedback}
              onSimilar={onSimilar}
              onDetail={onDetail}
              isSimilarLoading={similarLoadingId === item.id}
              dismissed={dismissedIds.has(item.id)}
              showDetails
            />
          ))}
          {hasMore && (
            <div className="flex-shrink-0 w-40 flex items-center justify-center">
              <button onClick={() => setVisibleCount(v => v + 10)}
                className="flex flex-col items-center gap-2 text-zinc-500 hover:text-zinc-300 transition-colors">
                <div className="w-10 h-10 rounded-full border border-zinc-700 hover:border-zinc-500 flex items-center justify-center">
                  <ChevronDown size={18} />
                </div>
                <span className="text-[10px]">+{filtered.length - visibleCount} altri</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  )
})


const INITIAL_VISIBLE = 20
const LOAD_MORE_STEP = 10

const RecommendationSection = memo(function RecommendationSection({ type, items, label, onFeedback, dismissedIds, onSimilar, onDetail, similarLoadingId, isPrimary }: {
  type: MediaType; items: Recommendation[]; label: string
  onAdd: (i: Recommendation) => void; onWishlist: (i: Recommendation) => void
  onFeedback: (i: Recommendation, a: FeedbackAction, reason?: FeedbackReason) => void
  dismissedIds: Set<string>
  onSimilar?: (i: Recommendation) => void
  onDetail?: (i: Recommendation) => void
  similarLoadingId?: string | null
  isPrimary?: boolean
}) {
  const [visibleCount, setVisibleCount] = useState(INITIAL_VISIBLE)  // Fix 2.13
  const Icon = TYPE_ICONS[type]; const colorClass = TYPE_COLORS[type]
  const visible = items.filter(i => !dismissedIds.has(i.id))
  if (!visible.length) return null

  const shown = visible.slice(0, visibleCount)
  const hasMore = visible.length > visibleCount
  const topScore = visible[0]?.matchScore || 0

  return (
    <div className="mb-10">
      <div className="flex items-center gap-3 mb-4">
        <div className={`w-8 h-8 bg-gradient-to-br ${colorClass} rounded-xl flex items-center justify-center shadow-lg`}>
          <Icon size={16} className="text-white" />
        </div>
        <div>
          <h2 className="text-base font-bold text-white">{label}</h2>
          <p className="text-[10px] text-zinc-500">{visible.length} titoli</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {isPrimary && (
            <span className="text-[10px] font-semibold text-fuchsia-300 bg-fuchsia-500/10 border border-fuchsia-500/20 px-2 py-0.5 rounded-full">
              Il tuo tipo principale
            </span>
          )}
          {topScore >= 80 && !isPrimary && (
            <span className="text-[10px] font-semibold text-violet-400 bg-violet-500/10 border border-violet-500/20 px-2 py-0.5 rounded-full flex items-center gap-1">
              <Flame size={9} /> Ottimo match
            </span>
          )}
        </div>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-3 scrollbar-hide">
        {shown.map(item => (
          <RecommendationCard
            key={item.id} item={item} onFeedback={onFeedback} onSimilar={onSimilar} onDetail={onDetail}
            isSimilarLoading={similarLoadingId === item.id} dismissed={dismissedIds.has(item.id)}
          />
        ))}
        {hasMore && (
          <div className="flex-shrink-0 w-40 flex items-center justify-center">
            <button onClick={() => setVisibleCount(v => v + LOAD_MORE_STEP)}
              className="flex flex-col items-center gap-2 text-zinc-500 hover:text-zinc-300 transition-colors">
              <div className="w-10 h-10 rounded-full border border-zinc-700 hover:border-zinc-500 flex items-center justify-center">
                <ChevronDown size={18} />
              </div>
              <span className="text-[10px]">+{visible.length - visibleCount} altri</span>
            </button>
          </div>
        )}
      </div>
    </div>
  )
})

// Quick-reason modal — raccoglie il motivo dopo "non mi interessa"
function QuickReasonSheet({ item, onConfirm, onDismiss }: {
  item: Recommendation
  onConfirm: (reason: FeedbackReason) => void
  onDismiss: () => void
}) {
  useEffect(() => {
    androidBack.push(onDismiss)
    return () => androidBack.pop(onDismiss)
  }, [onDismiss])

  const options: { reason: FeedbackReason; label: string; sub: string; icon: React.ReactNode }[] = [
    {
      reason: 'not_my_genre',
      label: 'Non è il mio genere',
      sub: 'Aiuta a calibrare i tuoi gusti',
      icon: <X size={15} className="text-zinc-400" />,
    },
    {
      reason: 'bad_rec',
      label: 'Non fa per me',
      sub: 'Non suggerirlo più',
      icon: <ThumbsDown size={15} className="text-zinc-400" />,
    },
  ]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4" onClick={onDismiss}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="relative w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-3xl p-5"
        onClick={e => e.stopPropagation()}>
        <p className="text-xs font-semibold text-zinc-500 uppercase tracking-widest mb-1">Perché non ti interessa?</p>
        <p className="text-sm font-semibold text-white mb-5 truncate">{item.title}</p>
        <div className="space-y-2">
          {options.map(({ reason, label, sub, icon }) => (
            <button key={reason} onClick={() => onConfirm(reason)}
              className="w-full flex items-center gap-3.5 px-4 py-3.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 rounded-2xl transition-all text-left group">
              <div className="w-8 h-8 rounded-xl bg-zinc-800 group-hover:bg-zinc-700 flex items-center justify-center flex-shrink-0 transition-colors">
                {icon}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-white">{label}</p>
                <p className="text-[11px] text-zinc-500">{sub}</p>
              </div>
            </button>
          ))}
        </div>
        <button onClick={onDismiss}
          className="w-full mt-3 py-2.5 px-4 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-sm font-medium text-zinc-400 hover:text-zinc-200 transition-all">
          Annulla
        </button>
      </div>
    </div>
  )
}

function LowConfidenceBanner({ totalEntries }: { totalEntries: number }) {
  const needed = 15
  const pct = Math.min(100, Math.round((totalEntries / needed) * 100))
  return (
    <div className="flex items-start gap-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 mb-6">
      <AlertCircle size={18} className="text-amber-400 flex-shrink-0 mt-0.5" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-amber-300 mb-1">Consigli in miglioramento</p>
        <p className="text-xs text-amber-200/70 mb-3">
          I tuoi consigli migliorano man mano che aggiungi titoli. Hai ancora {needed - totalEntries} titoli per sbloccare i consigli personalizzati.
        </p>
        <div className="flex items-center gap-2">
          <div className="flex-1 h-1.5 bg-amber-500/20 rounded-full overflow-hidden">
            <div className="h-full bg-amber-400 rounded-full transition-all" style={{ width: `${pct}%` }} />
          </div>
          <span className="text-[10px] text-amber-400 font-bold">{totalEntries}/{needed}</span>
        </div>
        <Link href="/discover" className="inline-flex items-center gap-1.5 mt-3 text-xs font-semibold text-amber-400 hover:text-amber-300">
          <Plus size={13} />Aggiungi dalla libreria
        </Link>
      </div>
    </div>
  )
}

const FriendsWatchingSection = memo(function FriendsWatchingSection({ items }: { items: FriendActivity[] }) {
  if (!items.length) return null
  const timeAgo = (d: string) => {
    const diff = Date.now() - new Date(d).getTime()
    const h = Math.floor(diff / 3600000), days = Math.floor(diff / 86400000)
    if (h < 1) return 'ora'; if (h < 24) return `${h}h fa`; return `${days}g fa`
  }
  return (
    <div className="bg-zinc-900/60 border border-zinc-800 rounded-3xl p-5 mb-10">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-8 h-8 bg-gradient-to-br from-fuchsia-500 to-violet-500 rounded-xl flex items-center justify-center">
          <Users size={16} className="text-white" />
        </div>
        <h2 className="text-sm font-bold text-white">Amici che guardano</h2>
        <span className="text-xs text-zinc-500 ml-auto">{items.length}</span>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
        {items.map(a => (
          <Link key={`${a.userId}-${a.mediaId}`} href={`/profile/${a.username}`} className="flex-shrink-0 w-28 group">
            <div className="relative h-40 rounded-2xl overflow-hidden bg-zinc-800 mb-2">
              {a.mediaCover
                ? <img src={a.mediaCover} alt={a.mediaTitle} className="w-full h-full object-cover group-hover:scale-105 transition-transform" loading="lazy" />
                : <div className="w-full h-full flex items-center justify-center text-zinc-600"><Tv size={28} /></div>
              }
              <div className="absolute bottom-2 left-2 ring-2 ring-black rounded-full">
                <Avatar src={a.avatarUrl} username={a.username} displayName={a.displayName} size={24} />
              </div>
              <div className="absolute top-2 right-2 bg-black/70 text-[9px] text-zinc-300 px-1.5 py-0.5 rounded-full">{timeAgo(a.updatedAt)}</div>
            </div>
            <p className="text-[10px] font-semibold text-zinc-300 line-clamp-2 mb-0.5">{a.mediaTitle}</p>
            <p className="text-[9px] text-violet-400 truncate">@{a.username}</p>
          </Link>
        ))}
      </div>
    </div>
  )
})

// Module-level cache — sopravvive alle navigazioni nella stessa sessione
const forYouCache: {
  recommendations: Record<string, Recommendation[]> | null
  tasteProfile: TasteProfile | null
  friendsActivity: FriendActivity[]
  addedIds: Set<string>
  wishlistIds: Set<string>
  addedTitles: Set<string>
  totalEntries: number
  ts: number
} = {
  recommendations: null, tasteProfile: null, friendsActivity: [],
  addedIds: new Set(), wishlistIds: new Set(), addedTitles: new Set(),
  totalEntries: 0, ts: 0,
}

export default function ForYouPage() {
  const pathname = usePathname()
  const supabase = createClient(); const router = useRouter()
  const { t } = useLocale(); const fy = t.forYou
  const hasCachedData = forYouCache.recommendations !== null
  const [loading, setLoading] = useState(!hasCachedData); const [refreshing, setRefreshing] = useState(false)
  const [recommendations, setRecommendations] = useState<Record<string, Recommendation[]>>(forYouCache.recommendations ?? {})
  const [tasteProfile, setTasteProfile] = useState<TasteProfile | null>(forYouCache.tasteProfile)
  const [totalEntries, setTotalEntries] = useState(forYouCache.totalEntries)
  const [addedIds, setAddedIds] = useState<Set<string>>(forYouCache.addedIds)
  const [wishlistIds, setWishlistIds] = useState<Set<string>>(forYouCache.wishlistIds)
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set())
  const [showPrefs, setShowPrefs] = useState(false)
  const [isCached, setIsCached] = useState(hasCachedData)
  const [friendsActivity, setFriendsActivity] = useState<FriendActivity[]>(forYouCache.friendsActivity)
  const [friendsLoading, setFriendsLoading] = useState(!hasCachedData || forYouCache.friendsActivity.length === 0)
  const [addingIds, setAddingIds] = useState<Set<string>>(new Set())
  const [reasonPending, setReasonPending] = useState<Recommendation | null>(null)
  const [similarLoading, setSimilarLoading] = useState<string | null>(null)
  const [detailItem, setDetailItem] = useState<Recommendation | null>(null)
  const [similarSection, setSimilarSection] = useState<{ sourceTitle: string; sourceType: MediaType; items: Recommendation[] } | null>(null)
  const [showNewRecsBadge, setShowNewRecsBadge] = useState(false)
  const addedTitlesRef = useRef<Set<string>>(forYouCache.addedTitles)

  const fetchRecommendations = useCallback(async (force = false) => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { router.push('/login'); return }
    const res = await fetch(`/api/recommendations?type=all${force ? '&refresh=1' : ''}`)
    if (!res.ok) return
    const json = await res.json()
    const incoming = json.recommendations || {}
    // Merge invece di replace: non sovrascrivere con dati parziali.
    // Se la risposta contiene meno tipi di quelli in memoria, manteniamo i vecchi.
    setRecommendations(prev => {
      const merged = { ...prev }
      for (const [type, items] of Object.entries(incoming)) {
        if (Array.isArray(items) && items.length > 0) {
          merged[type] = items as Recommendation[]
        }
      }
      return merged
    })
    setTasteProfile(json.tasteProfile || null)
    setIsCached(!!json.cached)
  }, [])

  const fetchFriends = useCallback(async (userId: string) => {
    setFriendsLoading(true)
    try {
      const { data: follows } = await supabase.from('follows').select('following_id').eq('follower_id', userId)
      const ids = (follows || []).map((f: any) => f.following_id)
      if (!ids.length) { setFriendsActivity([]); setFriendsLoading(false); return }
      const since = new Date(Date.now() - 7 * 86400000).toISOString()
      const { data: entries } = await supabase.from('user_media_entries').select('user_id, external_id, title, cover_image, type, updated_at').in('user_id', ids).gte('updated_at', since).order('updated_at', { ascending: false }).limit(20)
      if (!entries?.length) { setFriendsActivity([]); setFriendsLoading(false); return }
      const uids = [...new Set(entries.map(e => e.user_id))]

      // Profiles + similarity in parallel → single setState, no double-render wave
      const [{ data: profiles }, { data: simData }] = await Promise.all([
        supabase.from('profiles').select('id, username, display_name, avatar_url').in('id', uids),
        supabase.from('taste_similarity').select('other_user_id, similarity_score')
          .eq('user_id', userId).in('other_user_id', ids).gte('similarity_score', 80),
      ])

      const pm: Record<string, any> = {}; profiles?.forEach(p => { pm[p.id] = p })
      const highSimIds = new Set((simData || []).map((s: any) => s.other_user_id))
      const simMap = Object.fromEntries((simData || []).map((s: any) => [s.other_user_id, s.similarity_score]))

      const seen = new Set<string>(); const activity: FriendActivity[] = []
      for (const e of entries) {
        const key = `${e.user_id}-${e.external_id}`
        if (seen.has(key)) continue; seen.add(key)
        const p = pm[e.user_id]; if (!p) continue
        activity.push({
          userId: e.user_id, username: p.username, displayName: p.display_name,
          avatarUrl: p.avatar_url, mediaId: e.external_id, mediaTitle: e.title,
          mediaCover: e.cover_image, mediaType: e.type, updatedAt: e.updated_at,
          isHighSim: highSimIds.has(e.user_id), simScore: simMap[e.user_id] || 0,
        })
      }
      const result = activity.slice(0, 12)
      setFriendsActivity(result)
      forYouCache.friendsActivity = result
    } catch { setFriendsActivity([]) }
    setFriendsLoading(false)
  }, [supabase])

  useEffect(() => {
    let cancelled = false
    let profileChannel: ReturnType<typeof supabase.channel> | null = null

    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user || cancelled) { if (!user) router.push('/login'); return }
      const userId = user.id

      // Realtime: aggiorna entry_count senza bloccare il rendering
      profileChannel = supabase
        .channel(`profile-entry-count-${userId}`)
        .on('postgres_changes', {
          event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${userId}`,
        }, (payload: any) => { setTotalEntries(payload.new?.entry_count ?? 0) })
        .subscribe()

      // ── Cache hit: mostra tutto immediatamente, poi aggiorna in background ──
      if (forYouCache.recommendations !== null) {
        // Aggiorna libreria e amici in background senza bloccare la UI
        Promise.all([
          supabase.from('user_media_entries').select('external_id, title').eq('user_id', userId),
          supabase.from('wishlist').select('external_id').eq('user_id', userId),
        ]).then(([{ data: entries }, { data: wish }]) => {
          const newAddedIds = new Set((entries || []).map((e: any) => e.external_id as string).filter(Boolean))
          const newTitles   = new Set((entries || []).map((e: any) => (e.title as string)?.toLowerCase()).filter(Boolean))
          const newWishIds  = new Set((wish || []).map((w: any) => w.external_id as string).filter(Boolean))
          setAddedIds(newAddedIds); setWishlistIds(newWishIds); setTotalEntries(entries?.length || 0)
          addedTitlesRef.current = newTitles
          forYouCache.addedIds = newAddedIds; forYouCache.wishlistIds = newWishIds
          forYouCache.addedTitles = newTitles; forYouCache.totalEntries = entries?.length || 0
        })
        fetchFriends(userId)
        return
      }

      // ── Cold start: fetch sequenziale ────────────────────────────────────────
      const [{ data: entries }, { data: wish }] = await Promise.all([
        supabase.from('user_media_entries').select('external_id, title').eq('user_id', userId),
        supabase.from('wishlist').select('external_id').eq('user_id', userId),
      ])

      const newAddedIds = new Set((entries || []).map((e: any) => e.external_id as string).filter(Boolean))
      const newTitles   = new Set((entries || []).map((e: any) => (e.title as string)?.toLowerCase()).filter(Boolean))
      const newWishIds  = new Set((wish || []).map((w: any) => w.external_id as string).filter(Boolean))
      setAddedIds(newAddedIds); setWishlistIds(newWishIds); setTotalEntries(entries?.length || 0)
      addedTitlesRef.current = newTitles
      forYouCache.addedIds = newAddedIds; forYouCache.wishlistIds = newWishIds
      forYouCache.addedTitles = newTitles; forYouCache.totalEntries = entries?.length || 0

      fetchFriends(userId)

      // 1. Pool persistente (fast path ~50ms)
      const poolRes = await fetch('/api/recommendations?source=pool')
      if (poolRes.ok) {
        const poolJson = await poolRes.json()
        if (poolJson.source === 'pool' && poolJson.recommendations) {
          const recs = poolJson.recommendations || {}
          setRecommendations(recs); setTasteProfile(poolJson.tasteProfile || null); setIsCached(true)
          forYouCache.recommendations = recs; forYouCache.tasteProfile = poolJson.tasteProfile || null
          forYouCache.ts = Date.now()
          setLoading(false)
          const lastVisit = localStorage.getItem('for_you_last_visit')
          const now = Date.now()
          if (lastVisit && now - parseInt(lastVisit || '') > 4 * 3600000) setShowNewRecsBadge(true)
          localStorage.setItem('for_you_last_visit', String(now))
          return
        }
      }

      // 2. Pool vuota → calcola tutto
      const recsRes = await fetch('/api/recommendations?type=all')
      if (recsRes.ok) {
        const json = await recsRes.json()
        const incoming = json.recommendations || {}
        const merged: Record<string, Recommendation[]> = {}
        for (const [type, items] of Object.entries(incoming)) {
          if (Array.isArray(items) && (items as any[]).length > 0) merged[type] = items as Recommendation[]
        }
        setRecommendations(merged); setTasteProfile(json.tasteProfile || null); setIsCached(!!json.cached)
        forYouCache.recommendations = merged; forYouCache.tasteProfile = json.tasteProfile || null
        forYouCache.ts = Date.now()
      }

      setLoading(false)
      const lastVisit = localStorage.getItem('for_you_last_visit')
      const now = Date.now()
      if (lastVisit && now - parseInt(lastVisit || '') > 4 * 3600000) setShowNewRecsBadge(true)
      localStorage.setItem('for_you_last_visit', String(now))
    }
    init()
    return () => {
      cancelled = true
      if (profileChannel) supabase.removeChannel(profileChannel)
    }
  }, [])

  const handleRefresh = async () => {
    setRefreshing(true)
    setShowNewRecsBadge(false)
    const { data: { user } } = await supabase.auth.getUser()
    const [json] = await Promise.all([
      fetch('/api/recommendations?source=refresh_pool')
        .then(r => r.ok ? r.json() : null)
        .catch(() => null),
      user ? fetchFriends(user.id) : Promise.resolve(),
    ])
    if (json && json.recommendations) {
      const incoming = json.recommendations as Record<string, Recommendation[]>
      setRecommendations(prev => {
        const merged = { ...prev }
        for (const [type, items] of Object.entries(incoming)) {
          if (Array.isArray(items) && items.length > 0) merged[type] = items
        }
        forYouCache.recommendations = merged
        forYouCache.ts = Date.now()
        return merged
      })
      if (json.tasteProfile) { setTasteProfile(json.tasteProfile); forYouCache.tasteProfile = json.tasteProfile }
      setIsCached(false)
    }
    setRefreshing(false)
  }

  // Pull-to-refresh su mobile — deve stare DOPO handleRefresh
  const { distance: pullDistance, refreshing: isPulling } = usePullToRefresh({
    onRefresh: handleRefresh,
    enabled: pathname === '/for-you',
  })

  const handleAdd = useCallback(async (item: Recommendation) => {
    const { data: { user } } = await supabase.auth.getUser(); if (!user) return
    const isBoardgame = item.type === 'boardgame'
    const bggAchievementData = isBoardgame && ((item as any).complexity != null || (item as any).min_players != null || (item as any).playing_time != null)
      ? { bgg: { score: (item as any).score ?? null, complexity: (item as any).complexity ?? null, min_players: (item as any).min_players ?? null, max_players: (item as any).max_players ?? null, playing_time: (item as any).playing_time ?? null } }
      : null
    const { error } = await supabase.from('user_media_entries').insert({
      user_id: user.id, external_id: item.id, title: item.title, type: item.type,
      cover_image: item.coverImage, genres: item.genres,
      tags: isBoardgame ? ((item as any).mechanics || []) : [],
      authors: isBoardgame ? ((item as any).designers || []) : [],
      achievement_data: bggAchievementData,
      status: (item.type === 'movie' || isBoardgame) ? 'completed' : 'watching',
      current_episode: isBoardgame ? null : 1,
      display_order: Date.now(),
    })
    if (!error) {
      setAddedIds(prev => new Set([...prev, item.id]))
      addedTitlesRef.current.add(item.title.toLowerCase())
      await fetch('/api/recommendations/feedback', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rec_id: item.id, rec_type: item.type, rec_genres: item.genres, action: 'added' })
      })
      if (item.genres.length > 0) {
        triggerTasteDelta({ action: 'status_change', mediaId: item.id, mediaType: item.type, genres: item.genres, status: item.type === 'movie' ? 'completed' : 'watching' })
      }
    }
  }, [supabase])

  const handleWishlist = useCallback(async (item: Recommendation) => {
    const { data: { user } } = await supabase.auth.getUser(); if (!user) return
    if (wishlistIds.has(item.id)) {
      await supabase.from('wishlist').delete().eq('user_id', user.id).eq('external_id', item.id)
      setWishlistIds(prev => { const s = new Set(prev); s.delete(item.id); return s })
    } else {
      await supabase.from('wishlist').upsert({
        user_id: user.id, external_id: item.id, title: item.title,
        type: item.type, cover_image: item.coverImage,
      }, { onConflict: 'user_id,external_id' })
      setWishlistIds(prev => new Set([...prev, item.id]))
      if (item.genres.length > 0) {
        triggerTasteDelta({ action: 'wishlist_add', mediaId: item.id, mediaType: item.type, genres: item.genres })
      }
    }
  }, [supabase, wishlistIds, t])

  // Fix 1.15: "Simili a questo" — richiede i consigli filtrati per i generi del titolo
  const handleDetail = useCallback((item: Recommendation) => {
    const details: MediaDetails = {
      id: item.id,
      title: item.title,
      type: item.type,
      coverImage: item.coverImage,
      year: item.year,
      genres: item.genres,
      description: item.description,
      score: item.score,
      episodes: item.episodes,
      authors: item.authors,
      developers: item.developers,
      platforms: item.platforms,
      why: item.why,
      matchScore: item.matchScore,
      isAwardWinner: item.isAwardWinner,
      source: item.id.startsWith('anilist-anime') ? 'anilist'
            : item.id.startsWith('anilist-manga') ? 'anilist'
            : item.id.startsWith('tmdb-') ? 'tmdb'
            : item.id.startsWith('igdb-') ? 'igdb'
            : item.id.startsWith('ol-') ? 'ol'
            : item.id.startsWith('bgg-') ? 'bgg'
            : item.type === 'boardgame' ? 'bgg'
            : /^\d+$/.test(item.id) && item.type === 'game' ? 'igdb'
            : /^\d+$/.test(item.id) && (item.type === 'movie' || item.type === 'tv' || item.type === 'anime') ? 'tmdb'
            : undefined,
    }
    setDetailItem(details as any)
  }, [])

  // searchSimilar e handleSimilar unite — searchSimilar dichiarata prima per evitare
  // problemi di closure con useCallback deps=[]
  const searchSimilar = useCallback(async (title: string, genres: string[], excludeId?: string, tags?: string[], keywords?: string[], type?: string) => {
    if (!genres.length) {
      return
    }
    const params = new URLSearchParams({ title, genres: genres.slice(0, 5).join(',') })
    if (tags?.length) params.set('tags', tags.slice(0, 15).join(','))
    if (keywords?.length) params.set('keywords', keywords.slice(0, 15).join(','))
    if (excludeId) params.set('excludeId', excludeId)
    if (type) params.set('type', type)
    const res = await fetch(`/api/recommendations/similar?${params}`)
    if (res.ok) {
      const json = await res.json()
      const items: Recommendation[] = (json.items || []).filter((r: Recommendation) => r.id !== excludeId)
      setSimilarSection({ sourceTitle: title, sourceType: (type as MediaType) || 'movie', items })
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } else {
    }
  }, [])

  const handleSimilar = useCallback(async (item: Recommendation) => {
    if (!item.genres.length) return
    setSimilarLoading(item.id)
    await searchSimilar(item.title, item.genres, item.id, item.tags, item.keywords, item.type)
    setSimilarLoading(null)
  }, [searchSimilar])

  const sendFeedback = useCallback(async (item: Recommendation, action: FeedbackAction, reason?: FeedbackReason) => {
    await fetch('/api/recommendations/feedback', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rec_id: item.id, rec_type: item.type, rec_genres: item.genres, action, reason: reason || null })
    })
    if (action === 'not_interested' && item.genres.length > 0) {
      triggerTasteDelta({ action: 'status_change', mediaId: item.id, mediaType: item.type, genres: item.genres, status: 'dropped' })
    }
  }, [])

  const handleFeedback = useCallback((item: Recommendation, action: FeedbackAction, reason?: FeedbackReason) => {
    setDismissedIds(prev => new Set([...prev, item.id]))
    if (action === 'not_interested' && reason === undefined) {
      // Fix 2.6: mostra quick-reason sheet invece di dismiss diretto
      setReasonPending(item)
      sendFeedback(item, action, undefined)  // invia subito senza reason, aggiorna se arriva
    } else {
      sendFeedback(item, action, reason)
    }
  }, [sendFeedback])

  const displayRecs = recommendations
  const allRecs = Object.values(displayRecs).flat()

  // Fix 2.9: eleva nelle sezioni i titoli guardati da amici con sim ≥80%
  const friendWatchingMap = new Map<string, string>()  // mediaId → username
  for (const a of friendsActivity) {
    if (a.isHighSim && a.mediaId && !friendWatchingMap.has(a.mediaId)) {
      friendWatchingMap.set(a.mediaId, a.displayName || a.username)
    }
  }
  // Inietta friendWatching nelle recs esistenti
  for (const recs of Object.values(displayRecs)) {
    for (const rec of recs) {
      if (friendWatchingMap.has(rec.id)) {
        rec.friendWatching = friendWatchingMap.get(rec.id)
        rec.matchScore = Math.min(100, rec.matchScore + 12)  // piccolo boost visibilità
      }
    }
  }

  const allContinuityRecs = allRecs.filter(i => i.isContinuity && !dismissedIds.has(i.id))

  const hasEnoughData = totalEntries >= 1

  // Mostra solo sezioni per tipi che l'utente ha nella collezione
  // E ordina per numero di titoli consigliati (sezioni più ricche prima)
  const collectionSize = tasteProfile?.collectionSize || {}
  const ALL_SECTIONS: Array<{ key: MediaType; label: string }> = [
    { key: 'anime', label: fy.sections.anime },
    { key: 'game', label: fy.sections.game },
    { key: 'movie', label: fy.sections.movie },
    { key: 'tv', label: fy.sections.tv },
    { key: 'manga', label: fy.sections.manga },
    { key: 'boardgame', label: fy.sections.boardgame },
  ]
  // Fix 2.4: ordina per affinità reale (collectionSize nel profilo) non per count consigli
  // Chi ha più titoli nel profilo viene prima — riflette il tipo centrale per l'utente
  const SECTIONS = ALL_SECTIONS.filter(({ key }) =>
    (collectionSize[key] || 0) >= 1 || (displayRecs[key] || []).length >= 1
  ).sort((a, b) => {
    const sizeA = collectionSize[a.key] || 0
    const sizeB = collectionSize[b.key] || 0
    return sizeB - sizeA
  })
  const primarySectionKey = SECTIONS[0]?.key



  if (loading) return (
    <div className="min-h-screen bg-black text-white">
      <div className="pt-2 md:pt-8 pb-28 max-w-screen-2xl mx-auto px-3 sm:px-4 md:px-6">
        {/* Utility bar skeleton */}
        <div className="flex justify-end items-center gap-2 mb-4 animate-pulse">
          <div className="h-8 w-28 bg-zinc-900 border border-zinc-800/80 rounded-xl" />
          <div className="h-8 w-8 bg-zinc-900 border border-zinc-800/80 rounded-xl" />
        </div>
        {/* Search bar "Trova simili a…" */}
        <div className="h-9 w-full bg-zinc-900 rounded-2xl mb-6 animate-pulse" />
        <SkeletonForYouRow />
        <SkeletonForYouRow />
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-black text-white">
      <PullToRefreshIndicator distance={pullDistance} refreshing={isPulling} />
      <div className="pt-2 md:pt-8 pb-24 max-w-screen-2xl mx-auto px-3 sm:px-4 md:px-6">

        {/* Utility bar — solo controlli, senza titolo ridondante */}
        <div className="flex justify-end items-center gap-2 mb-4">
          <button onClick={() => setShowPrefs(true)}
            className="flex items-center gap-2 px-3.5 py-2 bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 rounded-xl text-xs font-medium text-zinc-400 hover:text-zinc-200 transition-all">
            <SlidersHorizontal size={13} />
            <span className="hidden sm:inline">{fy.preferences}</span>
          </button>
          <div className="relative">
            <button onClick={handleRefresh} disabled={refreshing}
              className="w-8 h-8 flex items-center justify-center bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 disabled:opacity-40 rounded-xl text-zinc-400 hover:text-zinc-200 transition-all">
              <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} />
            </button>
            {showNewRecsBadge && (
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-fuchsia-500 rounded-full border border-black animate-pulse" />
            )}
          </div>
        </div>

        {!hasEnoughData ? (
          <EmptyState
            icon={Sparkles}
            title={fy.title}
            description={fy.emptyState}
            action={{ label: fy.emptyStateCta, href: '/discover' }}
            accent="fuchsia"
          />
        ) : (
          <>
            {totalEntries < 15 && <LowConfidenceBanner totalEntries={totalEntries} />}
            {tasteProfile && <DNAWidget tasteProfile={tasteProfile} totalEntries={totalEntries} />}
            {/* Barra ricerca libera "Trova simili a..." */}
            <SimilarSearchBar
              onSearch={(title, genres, keywords, type) => searchSimilar(title, genres, undefined, undefined, keywords, type)}
              loading={!!similarLoading}
            />

            {similarSection && (
              <SimilarSection
                key={similarSection.sourceTitle}
                sourceTitle={similarSection.sourceTitle}
                sourceType={similarSection.sourceType}
                items={similarSection.items}
                onFeedback={handleFeedback}
                onSimilar={handleSimilar}
                onDetail={handleDetail}
                onClose={() => setSimilarSection(null)}
                dismissedIds={dismissedIds}
                similarLoadingId={similarLoading}
              />
            )}
            {SECTIONS.map(({ key, label }) => {
              const items = displayRecs[key] || []
              const allItems = items
                .filter(i => !dismissedIds.has(i.id))
                .sort((a, b) => b.matchScore - a.matchScore)
              if (!allItems.length) return null
              return (
                <RecommendationSection
                  key={key}
                  type={key}
                  items={allItems}
                  label={label}
                  onAdd={handleAdd}
                  onWishlist={handleWishlist}
                  onFeedback={handleFeedback}
                  dismissedIds={dismissedIds}
                  onSimilar={handleSimilar}
                  onDetail={handleDetail}
                  similarLoadingId={similarLoading}
                  isPrimary={key === primarySectionKey}
                />
              )
            })}

            {SECTIONS.every(({ key }) => {
              const items = (displayRecs[key] || []).filter(i => !dismissedIds.has(i.id))
              return !items.length
            }) && (
              <div className="text-center py-20">
                <p className="text-zinc-400">{fy.sectionEmpty}</p>
                <button onClick={handleRefresh} className="mt-4 text-violet-400 text-sm hover:underline">{fy.refresh}</button>
              </div>
            )}
          </>
        )}
      </div>
      {showPrefs && <PreferencesModal onClose={() => setShowPrefs(false)} onSaved={handleRefresh} />}
      {/* Drawer dettaglio titolo — stesso del Discover */}
      {detailItem && (
        <MediaDetailsDrawer
          media={detailItem as any}
          onClose={() => setDetailItem(null)}
          onAdd={(media) => {
            setAddedIds(prev => new Set([...prev, media.id]))
            addedTitlesRef.current.add((media.title as string)?.toLowerCase())
            setDetailItem(null)
            profileInvalidateBridge.invalidate()
          }}
        />
      )}
      {/* Fix 2.6: quick-reason sheet */}
      {reasonPending && (
        <QuickReasonSheet
          item={reasonPending}
          onConfirm={(reason) => {
            if (reason !== undefined) sendFeedback(reasonPending, 'not_interested', reason)
            setReasonPending(null)
          }}
          onDismiss={() => setReasonPending(null)}
        />
      )}
    </div>
  )
}