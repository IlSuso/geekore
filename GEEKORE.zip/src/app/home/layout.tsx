import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Home',
  description: 'Il feed della community Geekore — post, aggiornamenti e progressi degli utenti che segui.',
  openGraph: {
    title: 'Home — Geekore',
    description: 'Il feed della community Geekore — post, aggiornamenti e progressi degli utenti che segui.',
    type: 'website',
  },
  twitter: {
    card: 'summary',
    title: 'Home — Geekore',
    description: 'Il feed della community Geekore.',
  },
}

export default function HomeLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
