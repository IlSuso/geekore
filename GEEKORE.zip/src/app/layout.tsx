// DESTINAZIONE: src/app/layout.tsx
// FIX stacking context navbar:
//   Il precedente <div style={{ viewTransitionName: 'navbar' }}> attorno a <Navbar>
//   creava un nuovo stacking context che intrappolava il z-index della navbar,
//   permettendo agli elementi delle pagine di coprirla durante lo scroll.
//   Soluzione: wrapper rimosso. La viewTransitionName è ora sui tag <nav> interni.
//   Rimosso anche viewTransitionName sull'<html> per lo stesso motivo.

import type { Metadata, Viewport } from 'next'
import { Plus_Jakarta_Sans } from 'next/font/google'
import './globals.css'
import Navbar from '@/components/Navbar'

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['600', '700', '800'],
  variable: '--font-display',
  display: 'swap',
})

import { ClientProviders } from '@/components/ClientProviders'
import { Footer } from '@/components/Footer'
import { MobileHeader } from '@/components/MobileHeader'
import { SwipeablePageContainer } from '@/components/SwipeablePageContainer'
import { KeepAliveTabShell } from '@/components/KeepAliveTabShell'import { MainShell } from '@/components/MainShell'
import { cookies } from 'next/headers'

export const metadata: Metadata = {
  title: { default: 'Geekore', template: '%s — Geekore' },
  description: 'Traccia anime, manga, videogiochi, film e serie in un unico posto. Condividi i tuoi progressi con la community.',
  manifest: '/manifest.json',
  icons: {
    icon: '/icons/favicon-32.png',
    apple: '/icons/apple-touch-icon.png',
  },
  openGraph: {
    title: 'Geekore',
    description: 'Il tuo universo geek in un unico posto.',
    type: 'website',
    locale: 'it_IT',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Geekore',
    description: 'Il tuo universo geek in un unico posto.',
  },
}

export const viewport: Viewport = {
  themeColor: '#000000',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  viewportFit: 'cover',
  colorScheme: 'dark',
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const cookieStore = await cookies()
  const localeCookie = cookieStore.get('geekore_locale')?.value
  const initialLocale = localeCookie === 'en' ? 'en' : 'it'

  return (
    <html lang="it">
      <head>
        <meta name="view-transition" content="same-origin" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="color-scheme" content="dark" />
        <meta name="theme-color" content="#000000" />
        <meta name="theme-color" content="#000000" media="(prefers-color-scheme: dark)" />
        <meta name="theme-color" content="#000000" media="(prefers-color-scheme: light)" />
      </head>
      <body suppressHydrationWarning className={`${jakarta.variable} bg-black text-white min-h-screen antialiased`}>
        <ClientProviders initialLocale={initialLocale}>
          <SwipeablePageContainer>
            <MainShell>
              <KeepAliveTabShell>
                {children}
              </KeepAliveTabShell>
            </MainShell>
          </SwipeablePageContainer>
          <Footer />
          {/* Fixed UI — rendered AFTER page content so the GPU compositor
              always layers them on top regardless of z-index confusion */}
          <MobileHeader />
          <Navbar />
        </ClientProviders>
      </body>
    </html>
  )
}